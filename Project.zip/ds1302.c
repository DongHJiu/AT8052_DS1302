#include "DS1302.h"


sbit DSIO = P1^5;
sbit RST  = P1^6;
sbit SCLK = P1^7;

uchar ds1302_readstorage[7]={0x81, 0x83, 0x85, 0x87, 0x89, 0x8b, 0x8d};
uchar ds1302_writestorage[7]={0x80, 0x82, 0x84, 0x86, 0x88, 0x8a, 0x8c};

uchar TIME[7] = {0, 0, 0x12, 0x07, 0x05, 0x06, 0x16};                 //ds1302初始值

/*向DS1302寄存器器写入数据*/
void ds1302_writes(uchar location,uchar location_data){
	uchar i;
	RST=0;
	_nop_();
	SCLK=0;
	_nop_();
	RST=1;
	_nop_();
	for(i=0;i<8;i++){
		DSIO=location&0x01;
		location>>=1;
		SCLK=1;
		_nop_();
		SCLK=0;
		_nop_();
	}
	for(i=0;i<8;i++){
		DSIO=location_data&0x01;
		location_data>>=1;
		SCLK=1;
		_nop_();
		SCLK=0;
		_nop_();
	}
	RST=0;
	_nop_();
}

/*读取DS1302寄存器的数据*/
uint ds1302_read(uchar location){
	uchar read_data,read_data1,i;
	RST=0;
	_nop_();
	SCLK=0;
	_nop_();
	RST=1;
	_nop_();
	for(i=0;i<8;i++){
		DSIO=location&0x01;
		location>>=1;
		SCLK=1;
		_nop_();
		SCLK=0;
		_nop_();
	}
	for(i=0;i<8;i++){
		read_data=DSIO;
		read_data1=(read_data1>>1)|(read_data<<7);
		SCLK=1;
		_nop_();
		SCLK=0;
		_nop_();	
	}
	RST = 0;
	_nop_();	
	SCLK = 1;
	_nop_();
	DSIO = 0;
	_nop_();
	DSIO = 1;
	_nop_();
	return read_data1;
}

/*循环读取DS1302寄存器的数据*/
void ds1302_TIMEdata(){
	uchar i;
	for(i=0;i<8;i++){
		TIME[i]=ds1302_read(ds1302_readstorage[i]);
	}
}

/*DS1302初始化*/
void ds1302_Init(){
	uchar i;
	ds1302_writes(0x8E,0x00);                                           //关闭写保护
	for(i=0;i<8;i++){
		ds1302_writes(ds1302_writestorage[i],TIME[i]);
	}
	ds1302_writes(0x8E,0x80);
}
