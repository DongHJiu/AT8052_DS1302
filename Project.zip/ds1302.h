#ifndef __DS1302_H
#define __DS1302_H

#include <reg52.h>
#include <intrins.h>

#ifndef uchar
#define uchar unsigned char 
#endif

#ifndef uint
#define uint unsigned int	
#endif


void ds1302_Init();
void ds1302_TIMEdata();
extern uchar TIME[7];

#endif
